/* 
 * File:   main.cpp
 * Author: Ferny Hernandez
 * Created on June 29, 2022, 7:00 PM
 * Purpose: Homework Problem 6 / Personal Information
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Mathematical/Physics/Conversions, Higher dimensioned arrays

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    
    //Initialize the Random Number Seed
     
    //Declare Variables
    
    //Initialize Variables
    string name = "Ferny Hernandez", //My personal information for the code
           address = "5192 Riverside Ave, Riverside",
           phone = "909-123-4567",
           major = "Comp Sci";
    //Map inputs to outputs -> The Process
    
    //Display Results
    cout << "Name:    " << name << endl;
    cout << "Address: " << address << endl;
    cout << "Phone:   " << phone << endl;
    cout << "Major:   " << major << endl;
    
    //Exit stage right
    return 0;
}

